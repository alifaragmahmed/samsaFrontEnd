import { TrustedStyleString } from '@angular/core/src/sanitization/bypass';

export interface IReqRegisterationStatus{
    name:string;
    notes:string;
}