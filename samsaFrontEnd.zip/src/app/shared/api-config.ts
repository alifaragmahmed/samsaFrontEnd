export class ApiConfig {

    public static BASE_URL = "http://samsa.sphinxws.com/api";
}
