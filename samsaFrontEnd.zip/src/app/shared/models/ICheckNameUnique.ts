export interface ICheckNameUnique {
    name: string;
    _id?: string;
}