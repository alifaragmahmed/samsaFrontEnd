export interface IVenue {
    _id: string,
    name_en: string,
    name_ar: string,
    published: boolean
}
