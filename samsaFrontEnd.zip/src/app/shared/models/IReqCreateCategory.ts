export interface IReqCreateCategory {
    name_en: string,
    name_ar: string,
    published: boolean
}