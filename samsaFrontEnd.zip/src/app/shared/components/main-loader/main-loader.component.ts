import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-loader',
  templateUrl: './main-loader.component.html'
})
export class MainLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
