export class Gender {

  public static MALE: any = 'male';
  public static FEMALE: any = 'female';
}
