import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-military',
  templateUrl: './military.component.html',
  styleUrls: ['./military.component.scss']
})
export class MilitaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
