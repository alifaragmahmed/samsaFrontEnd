export interface IReqCreateAdminUser {
  email: string;
  password: string;
  name: string;
  role: string;
}
