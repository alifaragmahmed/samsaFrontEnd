export interface IResAdminUserList {
  _id?: string;
  email: string;
  name: string;
  active: boolean;
  role: string;
}
