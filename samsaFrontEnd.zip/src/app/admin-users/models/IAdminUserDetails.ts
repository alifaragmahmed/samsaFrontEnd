export interface IAdminUserDetails {
  _id?: string;
  email: string;
  name: string;
  active: boolean;
  role: string;
}
