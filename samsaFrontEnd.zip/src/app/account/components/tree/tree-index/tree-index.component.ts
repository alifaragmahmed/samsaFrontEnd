import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tree-index',
  templateUrl: './tree-index.component.html',
  styleUrls: ['./tree-index.component.scss']
})
export class TreeIndexComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
