export const environment = {
  production: true,
  // apiUrl      : 'http://41.41.86.210:4000/admin/api',
  // backEndPublicUrl   : 'http://41.41.86.210:4000/',
  publicUrl   : window.location.origin,
  // https://samsav2.sphinxws.com/public
  // http://127.0.0.1:8000
  // http://localhost/samsa-backend/public
  // window.location.hostname
  //192.168.43.159
  apiUrl: window.location.origin + '/api',
  backEndPublicUrl: 'http://localhost:4000/',
  googleApiKey: 'AIzaSyAtCTUfmq6JOFrE9Ib_HPEPFhUE9VdwcEs',
  frontEndPublicUrl: 'http://127.0.0.1:4200/'

};
